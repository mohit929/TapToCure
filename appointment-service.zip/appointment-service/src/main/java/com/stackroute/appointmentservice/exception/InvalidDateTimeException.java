package com.stackroute.appointmentservice.exception;

public class InvalidDateTimeException extends Exception {
    public InvalidDateTimeException(String message) {
        super(message);
    }
}
