package com.stackroute.appointmentservice.model;

public enum AppointmentStatus {
    AVAILABLE, BOOKED, CANCELLED
}
