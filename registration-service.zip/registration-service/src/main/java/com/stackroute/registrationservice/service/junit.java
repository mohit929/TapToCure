package com.stackroute.registrationservice.service;

public class junit {
}
