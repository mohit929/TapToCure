package com.stackroute.registrationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
